সত্য খবর নিউজ — পাবলিক ওয়েবসাইট ও ব্যক্তিগত সংবাদ এডিটর (v3)

১. public/ ফোল্ডারের ৬টি ফাইল GitHub Repository-এর main root-এ রাখুন: index.html, app.css, site.js, data.js, news.json, settings.json।
২. private-editor/ ফোল্ডারের admin.html, admin.js ও অন্যান্য সহায়ক ফাইল শুধু নিজের ফোন/কম্পিউটারে রাখুন; পাবলিক GitHub-এ দেবেন না।
৩. GitHub থেকে বিদ্যমান news.json এবং settings.json ডাউনলোড করে এডিটরের Import দিয়ে আগে আনুন, যদি আগে সংবাদ প্রকাশ করে থাকেন।
৪. admin.html খুলে সংবাদ যোগ/সম্পাদনা/ডিলিট করুন। ছবি দিতে HTTPS ছবির URL ব্যবহার করুন; ছবি আপলোডের সার্ভার এই স্ট্যাটিক সংস্করণে নেই।
৫. সেটিংসে ইমেইল, ঘোষণা, লোগো URL, ফেসবুক, ইউটিউব, দুটি বিজ্ঞাপন ও যোগাযোগের লেখা সম্পাদনা করুন।
৬. Export থেকে news.json ও settings.json ডাউনলোড করুন। GitHub-এ বর্তমান ফাইল দুটির কনটেন্ট নতুন JSON দিয়ে প্রতিস্থাপন করে Commit changes দিন। নতুন সংবাদ ও সেটিংস তখন পাবলিক সাইটে আসবে।
৭. GitHub Pages: Settings > Pages > Deploy from branch > main / root।
৮. পূর্বে আপলোড করা admin.html, admin.js এবং ZIP ফাইল GitHub পাবলিক Repository থেকে মুছে দিন।
৯. ব্রাউজারের লোকাল স্টোরেজ পরিষ্কার করলে এডিটরের ডেটা হারাতে পারে; প্রতিবার JSON ব্যাকআপ রাখুন। আলাদা ডিভাইসে কাজ করলে আগের JSON Import করুন।
১০. এই সংস্করণে Firebase, অনলাইন Admin Login, স্বয়ংক্রিয় Publish, প্রকৃত ভিউ গণনা, AdSense অনুমোদন বা আয় চালু নেই। বিজ্ঞাপন ব্যানারের লিংক/ছবি কেবল প্রচার দেখায়।
১১. কোনো নমুনা/ভুয়া সংবাদ প্রকাশিত নয়; news.json শুরুতে খালি।
১২. ইমেইল না বসানো পর্যন্ত mailto যোগাযোগ ঠিকভাবে কাজ করবে না।

LIVE: https://shajibi639-design.github.io/sotto-khobor-news/
UPLOAD: https://github.com/shajibi639-design/sotto-khobor-news/upload/main
