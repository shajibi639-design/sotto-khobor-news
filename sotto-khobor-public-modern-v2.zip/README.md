# সত্য খবর নিউজ — Public Website v2

## GitHub Pages upload
Upload the six files in `public-upload/` to the root of `shajibi639-design/sotto-khobor-news` (replace existing files).
Delete the already uploaded `admin.html`, `admin.js`, and the old ZIP from the public repository. The `offline-editor/` folder is for your own device only.

## Publishing news
Open offline-editor/admin.html on your device, write and save the article, export the updated `news.json`, then replace `news.json` in the public repository. Settings are published by replacing `settings.json`. No Firebase. No public login.

## Important
The existing demo news are samples, not factual news. Remove them before real launch. Replace the contact email in settings.json. AdSense and analytics are not installed, so views do not yet generate revenue. Do not publish a privacy-policy claim about analytics/ads until those are configured.

## Tested
JavaScript syntax and JSON parse checks. Live GitHub Pages deployment and mobile browser interaction have not been tested.
